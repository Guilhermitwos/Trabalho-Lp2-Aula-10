using System;

namespace Aula10
{
        public class Triangulo_Retangulo : Figura 
        {
            private double _base;
            private double _altura;
           
            private double _ladoA;
            private double _ladoB;
            private double _ladoC;


 

           //=================================
            public Triangulo_Retangulo
            (              
                    double base_, 
                    double altura_, 
                    double ladoA_,
                    double ladoB_,
                    double ladoC_                                  
            )  
            //=================================
            {       
                 this._base  = base_; 
                 this._altura = altura_;  
                 this._ladoA = ladoA_;    
                 this._ladoB = ladoB_;
                 this._ladoC = ladoC_;

                 this.AtualizarArea();
                 this.AtualizarPerimetro();       
           }
         //=================================




            private void AtualizarArea() 
            { 
            
                this._area = ( (this._base * this._altura) / 2 );

            }  
            private void AtualizarPerimetro() 
            {           
                this._perimetro = this._ladoA + this._ladoB + this._ladoC ;
            }
        
            
        }
}