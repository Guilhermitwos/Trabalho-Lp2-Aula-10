﻿
using System;
using System.Collections.Generic;

namespace Aula10

{
    class Program
    {


        //INSTANCIA A LISTA DOS CIRCULOS CONTENDO A CLASSE "Circulo"
        static List<Circulo> _Circulos;
        //INSTANCIA A LISTA DOS RETANGULOS CONTENDO A CLASSE "Retangulo"
        static List<Retangulo> _Retangulos;
        
        //INSTANCIA A LISTA DOS TRIANGULOS RETANGULO CONTENDO A CLASSE "Triangulo_Retangulo"
        static List<Triangulo_Retangulo> _TrianguloRetangulo;

        static void Main(string[] args)
        {
              
            //DEFINE O VALOR PARA A LISTA "_Circulos"
            _Circulos = new List<Circulo>();
            //DEFINE O VALOR PARA A LISTA "_Retangulos"
            _Retangulos = new List<Retangulo>();
             //DEFINE O VALOR PARA A LISTA "_TrianguloRetangulo"
            _TrianguloRetangulo = new List<Triangulo_Retangulo>();

           //==================================================

             
        
           // ADICIONA UM CÍRCULO DE RAIO IGUAL A 3 PARA A LISTA "_Circulos" 
            _Circulos.Add(new Circulo(raio: 3));

           // ADICIONA UM RETANGULO DE ALTURA IGUAL A 3 E LARGURA IGUAL A 10 PARA A LISTA "_Retangulos" 
            _Retangulos.Add(new Retangulo(altura :3, largura : 10));

           // ADICIONA UM TRIANGULO RETANGULO PARA A LISTA "_TrianguloRetangulo"
            _TrianguloRetangulo.Add(new Triangulo_Retangulo
            (            
              base_ : 12,
              altura_ : 6,
              ladoA_ : 4,
              ladoB_ : 4,
              ladoC_ : 4
              
            ));
         


        // MOSTRA NO CONSOLE TODOS OS CÍRCULOS DA LISTA "_Circulos"
            foreach (Circulo p in _Circulos)
            {
                Console.WriteLine("");
                Console.WriteLine("Figura: Círculo");
                Console.WriteLine("Área:{0}", p.Area);
                Console.WriteLine("Perimetro:{0}", p.Perimetro);
                Console.WriteLine("");
            }

      // MOSTRA NO CONSOLE TODOS OS RETANGULOS DA LISTA "_Retangulos"
           foreach (Retangulo p in _Retangulos)
            { 
                Console.WriteLine("");
                Console.WriteLine("Figura: Retângulo");
                Console.WriteLine("Área:{0}", p.Area);
                Console.WriteLine("Perimetro:{0}", p.Perimetro);
                Console.WriteLine("");
            }
     // MOSTRA NO CONSOLE TODOS OS TRIANGULOS RETANGULO DA LISTA "_TrianguloRetangulo"
           foreach (Triangulo_Retangulo p in _TrianguloRetangulo)
            { 
                Console.WriteLine("");
                Console.WriteLine("Figura: Triângulo Retângulo");
                Console.WriteLine("Área:{0}", p.Area);
                Console.WriteLine("Perimetro:{0}", p.Perimetro);
                Console.WriteLine("");
            }

           
  
  
            
            


        }
    }
}
